//speed 3, ani speed 2000, create speed 1700
//speed 2, ani speed 1700, create speed 1400
//speed 1, ani speed 1400, create speed 1100

var is_device = document.URL.indexOf( 'http://' ) === -1 && document.URL.indexOf( 'https://' ) === -1;

if(is_device)
	document.addEventListener('deviceReady', onDeviceReady);
else
	$(document).ready(init);

var fly_sound;
var crash_sound;
var admobid = {};

function onDeviceReady(){
	fly_sound = new Media('sounds/fly.mp3');
	crash_sound = new Media('sounds/crash.mp3');
	fly_sound.setVolume(1);
	crash_sound.setVolume(1);

	if( /(android)/i.test(navigator.userAgent) ){
		admobid = { // for Android
			banner: 'ca-app-pub-8099513553195534/7510762403',
			interstitial: 'ca-app-pub-8099513553195534/1464228807'
		};
	}else if(/(ipod|iphone|ipad)/i.test(navigator.userAgent)){
		admobid = { // for iOS
			banner: 'ca-app-pub-8099513553195534/7510762403',
			interstitial: 'ca-app-pub-8099513553195534/1464228807'
		};
	}else{
		admobid = { // for Windows Phone
			banner: 'ca-app-pub-8099513553195534/7510762403',
			interstitial: 'ca-app-pub-8099513553195534/1464228807'
		};
	}

	//Ads
	if(typeof AdMob != 'undefined'){
		AdMob.createBanner({
			adId : admobid.banner,
			position : AdMob.AD_POSITION.BOTTOM_CENTER,
			autoShow : true,
			isTesting: false, // REMOVE FOR PROD!!
		});

		// prepare a new interstitual
		AdMob.prepareInterstitial( {adId:admobid.interstitial, autoShow:false} );
	}

	init();

	setTimeout(function() {
        navigator.splashscreen.hide();
    }, 4000);
}

function init(){
	var $helicopter = $('#helicopter');
	var $body = $('body');
	var $wrapper = $('#wrapper');
	var $gameover = $('#gameover');
	var $gameover_overlay = $('#gameover-overlay');
	var $intro = $('#intro');
	var $instructions = $('#instructions');
	var $game_score = $('#end-score');
	var $best_score = $('#best-score');
	var $end_best_score = $('#end-best-score');
	var $score = $('#score');
	var cur_score = 0;
	var $roof = $('#roof');
	var roof_height = $roof.height();
	var $floor = $('#floor');
	var floor_height = set_floor_height();
	var $grass = $('.grass');
	var remove_block;
	var create_obstacles;
	var create_trails;
	var create_fire;
	var start_scoring;
	var next_score;
	var first_score;
	var delay_fall;
	var delay_fly;
	var window_width = parseInt($(window).width());
	var window_height = parseInt($(window).height());
	var copter_height = $helicopter.height();
	var copter_width = $helicopter.width();
	var start_pos;
	var min_gap = parseInt(copter_height) + 35; //set the min gap for calculations here based on copter height
	var min_top_pos = parseInt(min_gap + roof_height); // minimum position top for a feasable top gap
	var min_bottom_pos = parseInt(min_gap + floor_height); //minimim position bottom for a feasable bottom gap
	var min_height = set_min_height();
	var max_height = set_max_height(); //max height a block can be
	var max_bottom = window_height /2; //dont want a gap bigger than half the screen, too easy
	var max_top = window_height /2; //dont want a gap bigger than half the screen, too easy

	/* --  SETTINGS -- */
	var speed = 1.2; // set the speed depending on difficulty selected, lower = harder
	var ani_speed = set_ani_speed();
	var create_obstacle_speed = ani_speed - 400;

	var best_score = window.localStorage.getItem('helicopter_best_score');

	//for testing
	/*var is_device = 'ontouchend' in document;
	var start_event = is_device ? 'touchstart' : 'mousedown';
	var end_event = is_device ? 'touchend' : 'mouseup';
	*/

	//change for app deployment
	var start_event = 'ontouchend' in document ? 'touchstart' : 'mousedown';
	var end_event = 'ontouchend' in document ? 'touchend' : 'mouseup';

	// Show the start screen
	show_start();

	$instructions.on(start_event, function(){
		$body.on(start_event, copter_touchstart).on(end_event, copter_touchend);
		$instructions.hide();
		create_obstacles = setInterval(create_obstacle, create_obstacle_speed);
		check_collisions = setInterval(check_collision, 50);
		increase_speed = setInterval(increment_speed, 1000);
	});

	function set_ani_speed(){
		return 1100 + (speed * 300);
	}

	function increment_speed(){
		if(ani_speed > 1200){
			ani_speed = ani_speed -= 20;
		}
	}

	function set_min_height() {
		return window_height - floor_height - min_gap - 100;
	}

	function set_max_height() {
		return window_height - min_gap - roof_height - floor_height;
	}

	function set_floor_height() {
		return $floor.height();
	}

	function get_gap() {

	}

	function copter_touchstart(){
		var matrix = $helicopter.css('-webkit-transform').replace(/[^0-9\-.,]/g, '').split(',');
		var cur_top = matrix[5];
		var new_top = parseInt(cur_top - window_height);

		$helicopter.css('-webkit-transform', 'translate3d(0, '+ new_top +'px, 0)');

		setTimeout(function(){
			// play a flying sound
			if(is_device){
				fly_sound.play();
			}
		},20);
	}

	function copter_touchend(){
		var matrix = $helicopter.css('-webkit-transform').replace(/[^0-9\-.,]/g, '').split(',');
		var cur_top = matrix[5];
		var new_top = parseInt(cur_top) + window_height;

		$helicopter.css('-webkit-transform', 'translate3d(0, '+ new_top +'px, 0)');

		setTimeout(function(){
			//stop flying sound
			if(is_device){
				fly_sound.stop();
				fly_sound.release();
			}
		},20)
	}

	function grass_scroll(){
		$grass.css('-webkit-transition','all '+ ani_speed/1000 +'s linear');

		var current_bg_pos = $grass.css('background-position-x');
		var new_bg_pos = parseInt(current_bg_pos) - window_width;

		$grass.css('background-position-x', new_bg_pos+'px');
	}

	function create_obstacle(){
		var $block = $(document.createElement('div')).addClass('obstacle');

		var block_height = randomNumberFromRange(min_height, max_height);

		$block.css('height', block_height);

		/* -- code to decide where to place the block -- */

		// randomly generates either 0 or 1
		var top_bottom = Math.round(Math.random() * 1);

		// assign 0 to a block at bottom
		if(top_bottom === 0){

			//generate random number between 2 numbers.
			var rand_bottom = randomNumberFromRange(min_bottom_pos, max_bottom);

			$block.css('bottom', rand_bottom+'px')

		//else its 1, assign this to block at bottom
		}else{

			//generate random number between 2 numbers.
			var rand_top = randomNumberFromRange(min_top_pos, max_top);

			$block.css('top', rand_top+'px')

		}

		$block.css('-webkit-transition', 'all '+ ani_speed/1000 + 's linear');
		$wrapper.append($block);

		//set timeout to allow element to be in DOM before animating it
		setTimeout(function(){
			var $new_obstacle = $('.obstacle').not('.moving');
			$new_obstacle.addClass('moving').css('-webkit-transform','translate3d(-'+ parseInt(window_width + 40) +'px,0,0)');
			next_score = setTimeout(function(){
				add_score();
			},(ani_speed/5) *4);
		},20)

		// after the obstacle has gone accross screen, remove it
		remove_block = setTimeout(function(){
			$('.obstacle.moving').first().remove();
		},ani_speed);
	}

	function randomNumberFromRange(min,max){
	    return(Math.floor(Math.random()*(max-min+1)+min));
	}

	function create_trail(){
		var $trail = $(document.createElement('div')).addClass('trail');
		$trail.css('top', parseInt($helicopter.offset().top +5));
		$wrapper.prepend($trail);

		setTimeout(function(){
			var $new_trail = $('.trail').not('.move-trail');
			$new_trail.addClass('move-trail');

			setTimeout(function(){
				$new_trail.remove();
			},200)
		},10);
	}

	function fire(){
		var $fire = $(document.createElement('div')).addClass('fire');
		$fire.css({'top' : parseInt($helicopter.offset().top) , 'left' : parseInt($helicopter.offset().left)+25 });
		$wrapper.prepend($fire);

		setTimeout(function(){
			var $new_fire = $('.fire').not('.move-fire');
			$new_fire.addClass('move-fire');

			setTimeout(function(){
				$new_fire.remove();
			},200);
		},10);
	}

	function check_collision(){
		var offset = $helicopter.offset();
		var copter_top = offset.top;
		var copter_bottom = parseInt(copter_top + copter_height);
		var copter_left = offset.left;
		var copter_right = parseInt(copter_left + copter_width);

		var hit = false;

		if(copter_top <= 0){
			hit = true;
			show_gameover();
			//stop this continuing
			return false;
		}

		if(copter_bottom >= (window_height-floor_height)){
			hit = true;
			show_gameover(true, copter_top);
			//stop this continuing
			return false;
		}

		$.each($('.obstacle'), function(i, block){
			var block = $(block);
			var block_offset = block.offset();
			var block_top = block_offset.top;
			var block_bottom = parseInt(block_top + block.height());
			var block_left = block_offset.left;
			var block_right = parseInt(block_left + block.width());

			if(copter_top < block_bottom){
				if(copter_right > block_left){
					if(copter_bottom > block_top){
						if(copter_left < block_right){
							hit = true;
						}
					}
				}
			}

			if(hit){
				//clear all looping functions
				show_gameover();

				//stop this continuing
				return false;
			}

		});

	}

	function add_score(){
		cur_score = cur_score+=1;
		$score.text(cur_score);
	}

	function show_gameover(hit_bottom, copter_top){
		//remove touch listeners to control copter
		$body.off();

		if(is_device){
			//vibrate
			//navigator.notification.vibrate(300); BUGGY??!!

			//stop flying sound
			setTimeout(function(){
				fly_sound.stop();
				fly_sound.release();
			},30);
		}

		// play a crashing sound
		if(is_device){
			crash_sound.play({playAudioWhenScreenIsLocked : false});
			setTimeout(function(){
				crash_sound.release();
			},2500);
		}

		//clear all looping functions
		clearInterval(create_obstacles);
		clearInterval(check_collisions);
		clearInterval(create_trails);
		clearInterval(start_scoring);
		clearTimeout(next_score);
		clearTimeout(remove_block);
		clearInterval(scroll_grass);
		clearInterval(increase_speed);

		// Reset ani_speed
		ani_speed = set_ani_speed();

		//stop grass
		var current_bg_pos = $grass.css('background-position-x');
		$grass.removeAttr('style').css('background-position-x' , current_bg_pos);

		//make helicopter plumit to death
		//if we hit the bottom, dont move anything just keep still
		if(hit_bottom)
			$helicopter.addClass('fall').removeAttr('style').show().css('top', Math.round(copter_top));
		else
			$helicopter.addClass('fall').css('-webkit-transform','translate3d(0, '+ parseInt(window_height - start_pos - floor_height - copter_width + 20) +'px, 0) rotate(90deg)');

		//check best score + update if new best + show user
		best_score = window.localStorage.getItem('helicopter_best_score');
		var game_score = cur_score;
		$game_score.html('<span>YOUR SCORE</span>'+game_score);

		if(!best_score || (game_score > best_score)){
			best_score = game_score
			window.localStorage.setItem('helicopter_best_score', best_score);
			$end_best_score.html('<span>BEST SCORE</span>'+game_score);
			$game_score.addClass('new-best');

			// TODO: play a success kind of sound
		}

		$end_best_score.html('<span>BEST SCORE</span>'+best_score);
		$best_score.html('<span>BEST SCORE</span>'+best_score);

		//reset score
		cur_score = 0;

		//hide in game score
		$score.hide();

		//remove trail
		$('.trail').remove();

		// remove any obstacles
		$('.obstacle').remove();

		setTimeout(function(){

			//show gameover screen
			$gameover.show()
			setTimeout(function(){
				$gameover.addClass('show-gameover');
			},10);

			create_fire = setInterval(fire, 50);

		},500);
	}

	$('#ok').on(end_event, show_start);

	function show_start(){
		// show the interstitial later, e.g. at end of game level
		var rand_num = randomNumberFromRange(1, 3);
		if(rand_num == 2 && is_device && typeof AdMob != 'undefined'){
			AdMob.showInterstitial();
			// prepare a new interstitual
			AdMob.prepareInterstitial( {adId:admobid.interstitial, autoShow:false} );
		}

		clearInterval(create_fire);
		$('.fire').remove();
		$helicopter.removeAttr('style').removeClass('fall').hide();
		//set_difficulty();
		$gameover.hide().removeClass('show-gameover');
		$intro.show();

		best_score = window.localStorage.getItem('helicopter_best_score');

		if(best_score)
			$best_score.html('<span>BEST SCORE</span>'+best_score).show();

		// Reset this
		$game_score.removeClass('new-best');

		grass_scroll();
		scroll_grass = setInterval(grass_scroll, ani_speed);
	}

	$('#start').on(end_event, show_instructions);

	function show_instructions(){
		$intro.hide();
		$instructions.show();
		$helicopter.show();
		$score.text('0').show();
		start_pos = $helicopter.offset().top;

		create_trails = setInterval(create_trail, 50);
	}

	//setup hovers
	$('#start, #ok, .rate, .remove-ads').on(start_event, function(){
		$(this).addClass('hover');
	}).on(end_event, function(){
		$(this).removeClass('hover');
	});

	// Setup Rate button
	$('.rate').on(end_event, function(){
		if (is_device)
			var platform = device.platform;
		else
			var platform = 'android';

		if(platform.match(/ios/i))
			window.open('itms-apps://itunes.apple.com/us/app/domainsicle-domain-name-search/id511364723?ls=1&mt=8'); // or itms://
		else
			window.open('market://details?id=co.uk.rp_digital.helicopter_free');
	});

	// Setup Rate button
	$('.remove-ads').on(end_event, function(){
		if (is_device)
			var platform = device.platform;
		else
			var platform = 'android';

		if(platform.match(/ios/i))
			window.open('itms-apps://itunes.apple.com/us/app/domainsicle-domain-name-search/id511364723?ls=1&mt=8'); // or itms://
		else
			window.open('market://details?id=co.uk.rp_digital.helicopter_paid');
	});



	// difficulty
	//$('#easy, #medium, #hard').on(start_event, set_difficulty)

	/*function set_difficulty(){
		var $this = $(event.target);

		//check this isnt from the ok click event
		var id = $this.attr('id') != 'ok' ? $this.attr('id') : speed;

		//if id is undefined, its app open, so set default
		if(!id){
			id = 3;
		}

		switch(id){
			case 'easy':
			case 3:
				speed = 3;
				ani_speed = 1100 + (speed * 300);
				create_obstacle_speed = ani_speed - 400;
				$helicopter.attr('class','easy');
			break;
			case 'medium':
			case 2:
				speed = 2;
				ani_speed = 1100 + (speed * 300);
				create_obstacle_speed = ani_speed - 400;
				$helicopter.attr('class','medium');
			break;
			case 'hard':
			case 1:
				speed = 1;
				ani_speed = 1100 + (speed * 300);
				create_obstacle_speed = ani_speed - 400;
				$helicopter.attr('class','hard');
			break;
		}

		if(id != speed){
			$('.selected').removeClass('selected');
			$this.addClass('selected');
		}

	}*/


}